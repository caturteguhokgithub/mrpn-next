module.exports = {
 important: true,
 content: [
  "./src/pages/**/*.{js,ts,jsx,tsx}",
  "./src/app/**/*.{js,ts,jsx,tsx}",
  "./src/**/*.{js,ts,jsx,tsx}",
 ],
 theme: {
  extend: {
   //    fontFamily: {
   //     montserrat: ["Montserrat", "sans-serif"],
   //    },
  },
  colors: {
   primary: "#1880C9",
   dark: "#05004E",
   light: "#F4F5F7",
   white: "#FFFFFF",
   transparent: "transparent",
  },
 },
 plugins: [],
 corePlugins: {
  preflight: false,
 },
};
