import type { Metadata } from "next";
import theme from "../theme/theme";
import { ConfigProvider } from "antd";
import "../app/styles/style.scss";

export const metadata: Metadata = {
 title: "MRPN 2024",
 description: "Manajemen Risiko Pembangunan Nasional",
 icons: {
  icon: [
   {
    media: "(prefers-color-scheme: light)",
    url: "https://res.cloudinary.com/caturteguh/image/upload/v1708049745/mrpn/logo-2024_ne4yaj.png",
    href:
     "https://res.cloudinary.com/caturteguh/image/upload/v1708049745/mrpn/logo-2024_ne4yaj.png",
   },
   {
    media: "(prefers-color-scheme: dark)",
    url: "https://res.cloudinary.com/caturteguh/image/upload/v1708049745/mrpn/logo-2024_ne4yaj.png",
    href:
     "https://res.cloudinary.com/caturteguh/image/upload/v1708049745/mrpn/logo-2024_ne4yaj.png",
   },
  ],
 },
};

export default function RootLayout({
 children,
}: Readonly<{
 children: React.ReactNode;
}>) {
 return (
  <html lang="en">
   <body>
    <ConfigProvider theme={theme}>{children}</ConfigProvider>
   </body>
  </html>
 );
}
