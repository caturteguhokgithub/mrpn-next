import { MenuProps } from "antd";
import {
 IconAnalisis,
 IconDashboard,
 IconEvaluasi,
 IconExecutive,
 IconKeluar,
 IconPemantauan,
 IconPenetapan,
 IconProfil,
 IconManajemen,
} from "@/app/components/icons";
import Link from "next/link";

type MenuItem = Required<MenuProps>["items"][number];

// function getItem(
//  label: React.ReactNode,
//  key?: React.Key | null,
//  icon?: React.ReactNode,
//  type?: React.ReactNode,
//  children?: MenuItem[]
// ): MenuItem {
//  return {
//   key,
//   icon,
//   children,
//   label,
//   type,
//  } as MenuItem;
// }

function getItem(
 label: React.ReactNode,
 key: React.Key,
 icon?: React.ReactNode,
 children?: MenuItem[],
 type?: "group"
): MenuItem {
 return {
  key,
  icon,
  children,
  label,
  type,
 } as MenuItem;
}

export const items: MenuItem[] = [
 getItem(
  "Menu",
  "grpMenu",
  null,
  [
   getItem(<Link href="/">Dashboard</Link>, 1, <IconDashboard />),
   getItem(<Link href="/">Executive Summary</Link>, 2, <IconExecutive />),
   getItem("Penetapan Konteks", 3, <IconPenetapan />, [
    getItem("Option 3", "31"),
    getItem("Option 4", "32"),
   ]),
   getItem("Analisis Risiko", 4, <IconAnalisis />, [
    getItem("Option 7", "41"),
    getItem("Option 8", "42"),
    getItem("Option 9", "43"),
   ]),
   getItem(<Link href="/">Profil Risiko</Link>, 5, <IconProfil />),
   getItem(<Link href="/">Evaluasi Risiko</Link>, 6, <IconEvaluasi />),
   getItem("Pemantauan Pelaksanaan Mitigasi", 7, <IconPemantauan />, [
    getItem("Option 7", "71"),
    getItem("Option 8", "72"),
    getItem("Option 9", "73"),
   ]),
  ],
  "group"
 ),
 getItem(
  "Administrator",
  "grpAdmin",
  null,
  [
   getItem(
    <Link href="/manajemen-user">Manajemen User</Link>,
    8,
    <IconManajemen />
   ),
  ],
  "group"
 ),
 getItem(<Link href="/">Keluar Sistem</Link>, 9, <IconKeluar />),
];
