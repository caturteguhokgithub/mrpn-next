import React from "react";
import { Layout, Menu, Typography } from "antd";
import Image from "next/image";
import { items } from "./partials/menu";
import { useSelector } from "react-redux";
import {
 BrowserRouter,
 Router,
 useLocation,
 useNavigate,
} from "react-router-dom";
import { usePathname } from "next/navigation";
import Link from "next/link";

const { Sider } = Layout;

export default function Aside({ collapsed }: { collapsed: boolean }) {
 //  const location = useLocation();
 //  const { pathname } = location;

 //  const navigate = useNavigate;
 //  if (typeof window !== "undefined") {
 //  }

 let location = useLocation();
 const [current, setcurrent] = React.useState(
  location.pathname === "/" || location.pathname === ""
   ? "/dashboard"
   : location.pathname
 );
 //or simply use const [current, setcurrent] = usestate(location.pathname)

 React.useEffect(() => {
  if (location) {
   if (current !== location.pathname) {
    setcurrent(location.pathname);
   }
  }
 }, [location, current]);

 function handleclick(e: any) {
  setcurrent(e.key);
 }

 return (
  <Sider
   trigger={null}
   collapsible
   collapsed={collapsed}
   width={280}
   style={{ backgroundColor: "transparent" }}
  >
   {/* {menuItem.label}
   {menuItem.icon} */}
   <div className="flex items-center justify-center h-[120px] gap-[16px]">
    <Image
     width={64}
     height={68}
     src="https://res.cloudinary.com/caturteguh/image/upload/v1708049745/mrpn/logo-2024_ne4yaj.png"
     alt="MRPN 2024"
     priority
    />
    {collapsed ? null : (
     <Typography
      className={`max-w-[136px] leading-[1.3] text-[14px] font-[600] text-white font-['Open_Sans',_sans-serif] uppercase`}
     >
      Manajemen Risiko Pembangunan Nasional
     </Typography>
    )}
   </div>
   <div>
    <Menu
     className="bg-primary flex flex-col h-[calc(100vh-120px)] [&>li:last-of-type]:mt-auto [&>li:last-of-type]:mb-[20px] [&_li.ant-menu-item]:flex [&_li.ant-menu-item]:gap-2 [&>li.ant-menu-item-group+.ant-menu-item-group]:mt-8 [&_.ant-menu-title-content]:max-w-[100px] [&_.ant-menu-submenu-title]:gap-2"
     theme="dark"
     mode="inline"
     items={items}
     //  defaultSelectedKeys={[window.location.pathname]}
     selectedKeys={[window.location.pathname]}
     onClick={({ key }) => {
      if (key === "keluar-sistem") {
      } else {
       //    navigate(key);
      }
     }}
    />
    {/* <Menu onClick={handleclick} mode="vertical" selectedKeys={[current]}>
     <Link href="/">
      <Menu.Item key="/">dashboard</Menu.Item>
     </Link>
     <Link href="/manajemen-user">
      <Menu.Item key="/manajemen-user">manajemen-user</Menu.Item>
     </Link>
    </Menu> */}
   </div>
  </Sider>
 );
}
