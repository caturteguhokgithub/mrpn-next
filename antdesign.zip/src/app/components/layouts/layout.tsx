"use client";

import { usePathname } from "next/navigation";
import React from "react";
import { Button, Layout, Menu, Typography } from "antd";

import Image from "next/image";
import Link from "next/link";
import { FaAngleRight, FaAngleLeft } from "react-icons/fa6";
import Aside from "./aside";
import { BrowserRouter, Route, Routes } from "react-router-dom";

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

export default function DashboardLayout({
 children,
}: {
 children: React.ReactNode;
}) {
 const [collapsed, setCollapsed] = React.useState(false);

 return (
  <BrowserRouter>
   <Layout className="bg-primary">
    <Aside collapsed={collapsed} />
    <Layout className="bg-transparent min-h-[100vh]">
     <Header className="relative h-[80px] p-0 bg-transparent flex items-center">
      <div className="inline-flex items-center gap-[8px] pl-12">
       <Typography className="text-[20px] font-[800] uppercase text-white">
        MRPN 2024
       </Typography>
       <Typography className="text-[20px] font-[300] uppercase tracking-[4px] text-white">
        BAPPENAS
       </Typography>
      </div>
      <div
       className="inline-flex items-center justify-center bg-primary w-[27px] h-[27px] rounded-full cursor-pointer border-2 border-white border-solid absolute -bottom-[72px] -left-[12px]"
       onClick={() => setCollapsed(!collapsed)}
      >
       {collapsed ? (
        <FaAngleRight className="text-white relative -top-[1px]" />
       ) : (
        <FaAngleLeft className="text-white relative -top-[1px]" />
       )}
      </div>
     </Header>
     <Content className="rounded-ss-[50px] p-[42px] bg-light">
      {/* {children} */}
      <Routes>
       <Route path="/" element={children}></Route>
       <Route path="/manajemen-user" element={children}></Route>
      </Routes>
     </Content>
    </Layout>
   </Layout>
  </BrowserRouter>
 );
}
