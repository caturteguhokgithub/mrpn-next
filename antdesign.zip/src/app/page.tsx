// "use client";
// import PageDashboard from "./dashboard/page";
import { Button } from "antd";
import DashboardLayout from "./components/layouts/layout";

export default function Home() {
 return (
  <DashboardLayout>
   <Button type="primary">Dashboard</Button>
  </DashboardLayout>
 );
}
