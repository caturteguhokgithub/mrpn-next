"use client";

import { Button } from "antd";
import DashboardLayout from "../components/layouts/layout";

export default function PageUserManagement() {
 return (
  <DashboardLayout>
   <Button>Manajemen User</Button>
  </DashboardLayout>
 );
}
