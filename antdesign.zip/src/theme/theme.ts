import type { ThemeConfig } from "antd";

const theme: ThemeConfig = {
 token: {
  fontFamily: "'Poppins', sans-serif",
 },
 components: {
  Button: {
   fontSize: 14,
  },
 },
};

export default theme;
