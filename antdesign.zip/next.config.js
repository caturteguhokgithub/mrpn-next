const path = require("path");

/** @type {import('next').NextConfig} */

const nextConfig = {
 reactStrictMode: true,
 images: {
  remotePatterns: [
   {
    protocol: "https",
    hostname: "res.cloudinary.com",
    pathname: "**",
   },
  ],
 },
 compiler: {
  styledComponents: true,
 },
 sassOptions: {
  includePaths: [path.join(__dirname, "styles")],
 },
 transpilePackages: [
  "antd",
  "@ant-design",
  "rc-util",
  "rc-pagination",
  "rc-picker",
  "rc-notification",
  "rc-tooltip",
  "tailwindcss",
 ],
};

module.exports = nextConfig;

// export default nextConfig;
